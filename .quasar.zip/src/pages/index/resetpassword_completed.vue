<template>
    <div class="container">
        <div class="row justify-center">
            <div class="col-md-6 col-12">
                <q-card  flat bordered class="q-my-lg  text-center">
                    <q-card-section>
                        <div class="text-h5 text-bold text-positive">
                             <q-icon name="check_circle"></q-icon> votre mot de passe a été réinitialisé
                        </div>
                        <br />
                        <q-btn to="/"  no-caps unelevated icon="home" flat color="info">Cliquez ici pour vous identifier</q-btn>
                    </q-card-section>
                </q-card>
            </div>
        </div>
    </div>
</template>