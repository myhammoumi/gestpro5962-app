<template>
    <div class="container">
        <q-card  class="q-my-lg text-center nice-shadow-1">
            <q-card-section>
                <q-icon size="60px" color="positive" name="check_circle"></q-icon>
				<div class="text-h3 text-bold text-positive q-my-md">Toutes nos félicitations!</div>
                <div class="text-h6 text-grey">
                     Votre compte a été créé
                </div>
                <q-separator class="q-my-md" />
                <q-btn to="/home" no-caps unelevated icon="home" color="positive">Continuer</q-btn>
            </q-card-section>
        </q-card>
    </div>
</template>
