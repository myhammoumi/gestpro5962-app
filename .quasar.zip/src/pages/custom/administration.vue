<template>
    <q-page class="main-page"  id="">
        <section class="page-section q-pa-md" >
            <div class="container-fluid">
                <div class="row q-col-gutter-x-md">
                    <div  class="col comp-grid" >
                        <div class=" text-h6 text-bold" >
                            Administration
                        </div>
                    </div>
                    <div  class="col-12 comp-grid" >
                        <q-card  :flat="isSubPage" class=" nice-shadow-6">
                            <div >
                                <q-tabs v-model="TabPage409" align="left" :dense="true"  :inline-label="true" no-caps active-color="primary" indicator-color="primary">
                                    <q-tab name="TabPage409Page1"  label="Villes" />
                                    <q-tab name="TabPage409Page2"  label="Tarifs" />
                                    <q-tab name="TabPage409Page3"  label="Les Remises" />
                                    <q-tab name="TabPage409Page4"  label="Utilisateurs" />
                                    <q-tab name="TabPage409Page5"  label="permissions" />
                                    <q-tab name="TabPage409Page6"  label="Roles" />
                                </q-tabs>
                                <q-separator></q-separator>
                                <q-tab-panels keep-alive v-model="TabPage409" animated>
                                    <q-tab-panel  class="q-pa-none" name="TabPage409Page1">
                                        <div class="">
                                            <div class="reset-grid">
                                                <list-cpsvillesfr-page ref="cpsvillesfrListPage"  :limit="10" :show-header="true" :show-breadcrumbs="true" :show-footer="true" :paginate="true" page-store-key="ASSURE_LIST-CPSVILLESFR" is-sub-page>
                                                    </list-cpsvillesfr-page>
                                                </div>
                                            </div>
                                        </q-tab-panel>
                                        <q-tab-panel  class="q-pa-none" name="TabPage409Page2">
                                            <div class="">
                                                <div class="reset-grid">
                                                    <list-forfaittarif-page ref="forfaittarifListPage"  :limit="10" :show-header="true" :show-breadcrumbs="true" :show-footer="true" :paginate="true" page-store-key="ASSURE_LIST-FORFAITTARIF" is-sub-page>
                                                        </list-forfaittarif-page>
                                                    </div>
                                                </div>
                                            </q-tab-panel>
                                            <q-tab-panel  class="q-pa-none" name="TabPage409Page3">
                                                <div class="">
                                                    <div class="reset-grid">
                                                        <list-remises-page ref="remisesListPage"  :limit="10" :show-header="true" :show-breadcrumbs="true" :show-footer="true" :paginate="true" page-store-key="ASSURE_LIST-REMISES" is-sub-page>
                                                            </list-remises-page>
                                                        </div>
                                                    </div>
                                                </q-tab-panel>
                                                <q-tab-panel  class="q-pa-none" name="TabPage409Page4">
                                                    <div class="">
                                                        <div class="reset-grid">
                                                            <list-utilisateurs-page ref="utilisateursListPage"  :limit="10" :show-header="true" :show-breadcrumbs="true" :show-footer="true" :paginate="true" page-store-key="ASSURE_LIST-UTILISATEURS" is-sub-page>
                                                                </list-utilisateurs-page>
                                                            </div>
                                                        </div>
                                                    </q-tab-panel>
                                                    <q-tab-panel  class="q-pa-none" name="TabPage409Page5">
                                                        <div class="">
                                                            <div class="reset-grid">
                                                                <list-permissions-page ref="permissionsListPage"  :limit="10" :show-header="true" :show-breadcrumbs="true" :show-footer="true" :paginate="true" page-store-key="ASSURE_LIST-PERMISSIONS" is-sub-page>
                                                                    </list-permissions-page>
                                                                </div>
                                                            </div>
                                                        </q-tab-panel>
                                                        <q-tab-panel  class="q-pa-none" name="TabPage409Page6">
                                                            <div class="">
                                                                <div class="reset-grid">
                                                                    <list-roles-page ref="rolesListPage"  :limit="10" :show-header="true" :show-breadcrumbs="true" :show-footer="true" :paginate="true" page-store-key="ASSURE_LIST-ROLES" is-sub-page>
                                                                        </list-roles-page>
                                                                    </div>
                                                                </div>
                                                            </q-tab-panel>
                                                        </q-tab-panels>
                                                    </div>
                                                </q-card>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </q-page>
                        
</template>
<script setup>
	import {  computed, ref } from 'vue';
	
	
	import { useApp } from 'src/composables/app.js';
	
	
	import listCpsvillesfrPage from "../cpsvillesfr/list.vue";
import listForfaittarifPage from "../forfaittarif/list.vue";
import listRemisesPage from "../remises/list.vue";
import listUtilisateursPage from "../utilisateurs/list.vue";
import listPermissionsPage from "../permissions/list.vue";
import listRolesPage from "../roles/list.vue";
	
	const props = defineProps({
		pageName: {
			type: String,
			default: 'home',
		},
		routeName: {
			type: String,
			default: 'home',
		},
		isSubPage: {
			type : Boolean,
			default : false,
		},
	});
	const app = useApp();
	
	const pageReady = ref(true);
	const TabPage409 = ref('TabPage409Page1');
	
</script>
<style scoped>
</style>
